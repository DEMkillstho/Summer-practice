package com.platform.eduplatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduplatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
