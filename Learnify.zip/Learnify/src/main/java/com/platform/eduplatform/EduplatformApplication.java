package com.platform.eduplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EduplatformApplication {

    public static void main(String[] args) {
        SpringApplication.run(EduplatformApplication.class, args);
    }

}
