package com.platform.eduplatform.repository;

import com.platform.eduplatform.model.Result;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ResultRepo extends JpaRepository<Result, Integer> {
}
