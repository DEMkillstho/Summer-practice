package com.platform.eduplatform.model;


import java.util.List;

public class QuestionForm {

    private List<Question> questions;

    // Getter & Setter

    public List<Question> getQuestions() {
        return questions;
    }

    public void setQuestions(List<Question> questions) {
        this.questions = questions;
    }
}
