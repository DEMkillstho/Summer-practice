package com.platform.eduplatform.repository;

public class AnswerRepository {
}
