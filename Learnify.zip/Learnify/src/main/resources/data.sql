TRUNCATE TABLE questions RESTART IDENTITY ;

INSERT INTO questions (title, optiona, optionb, optionc, ans, chose) VALUES
('Which keyword is used to declare a constant variable in JavaScript??', 'let', 'const', 'var', 2, -1),
('What does the === operator do in JavaScript?', 'Assigns a value', 'Checks strict equality (value and type)', 'Performs a loose comparison', 2, -1),
('Which data structure follows the LIFO (Last-In-First-Out) principle?', 'Queue', 'Stack', 'Linked List', 2, -1);